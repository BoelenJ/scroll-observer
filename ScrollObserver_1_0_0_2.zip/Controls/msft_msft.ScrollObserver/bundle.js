/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./ScrollObserver/index.ts":
/*!*********************************!*\
  !*** ./ScrollObserver/index.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.ScrollObserver = void 0;\nvar ScrollObserver = /** @class */function () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function ScrollObserver() {\n    this.hasListener = false;\n    this.baselineDivId = \"\";\n    this.baseLineDivY = 0;\n    this.sortedSectionIds = [];\n    this.sectionElements = [];\n    this.focusedSection = null;\n    this.focusedSectionName = \"\";\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n  ScrollObserver.prototype.init = function (context, notifyOutputChanged, state, container) {\n    // Add control initialization code\n    this.notifyOutputChanged = notifyOutputChanged;\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n  ScrollObserver.prototype.updateView = function (context) {\n    var _this = this;\n    // Get the id of the baseline, only if it is set, continue.\n    var baselineDivId = context.parameters.BaselineDivId.raw;\n    if (!baselineDivId) return;\n    var sections = context.parameters.sections;\n    var sectionsChanged = context.updatedProperties.indexOf('dataset') > -1 || context.updatedProperties.indexOf('sections_dataset') > -1;\n    // Check if baseline div differs or sections have changed.\n    if (this.baselineDivId !== baselineDivId || sectionsChanged) {\n      // Remove listener if it exists.\n      if (this.hasListener) {\n        window.removeEventListener(\"scroll\", function () {\n          console.log(\"scroll event from pcf\");\n        }, true);\n      }\n      // Get the Y value of the baseline div.\n      this.baselineDivId = baselineDivId;\n      var baseLineDiv = document.querySelector(\"[id^=\\\"\".concat(baselineDivId, \"\\\"]\"));\n      if (baseLineDiv) {\n        this.baseLineDivY = baseLineDiv.getBoundingClientRect().y;\n        console.log(this.baseLineDivY);\n      }\n      // Get the sections.\n      this.sections = sections.records;\n      this.sortedSectionIds = sections.sortedRecordIds;\n      this.sectionElements = this.getSectionElements();\n      if (this.sectionElements.length > 0) {\n        this.hasListener = true;\n        // Add listener.\n        window.addEventListener(\"scroll\", function () {\n          _this.getFocusedSection(_this.baseLineDivY, _this.sectionElements, _this.notifyOutputChanged);\n        }, true);\n      }\n    }\n  };\n  ScrollObserver.prototype.getSectionElements = function () {\n    var sectionElements = [];\n    for (var i = 0; i < this.sortedSectionIds.length; i++) {\n      var section = this.sections[this.sortedSectionIds[i]];\n      var sectionId = section.getFormattedValue(\"DivId\");\n      var sectionName = section.getFormattedValue(\"Name\");\n      var sectionElement = document.querySelector(\"[id^=\\\"\".concat(sectionId, \"\\\"]\"));\n      if (sectionElement) {\n        sectionElements.push({\n          elementName: sectionName,\n          element: sectionElement\n        });\n      }\n    }\n    console.log(sectionElements);\n    return sectionElements;\n  };\n  ScrollObserver.prototype.getFocusedSection = function (baseline, sections, notifyOutputChanged) {\n    var focusedSection = null;\n    var closestDistance = Number.MAX_VALUE;\n    for (var i = 0; i < sections.length; i++) {\n      var section = sections[i];\n      var sectionY = section.element.getBoundingClientRect().y;\n      var distance = Math.abs(baseline - sectionY);\n      if (distance < closestDistance) {\n        closestDistance = distance;\n        focusedSection = section;\n      }\n    }\n    if (!focusedSection) return;\n    console.log(focusedSection.elementName);\n    if (this.focusedSection === focusedSection.element) return;\n    this.focusedSection = focusedSection.element;\n    this.focusedSectionName = focusedSection.elementName;\n    notifyOutputChanged();\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  ScrollObserver.prototype.getOutputs = function () {\n    return {\n      CurrentSection: this.focusedSectionName\n    };\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  ScrollObserver.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n    if (this.hasListener) {\n      window.removeEventListener(\"scroll\", function () {\n        console.log(\"scroll event from pcf\");\n      }, true);\n    }\n  };\n  return ScrollObserver;\n}();\nexports.ScrollObserver = ScrollObserver;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ScrollObserver/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./ScrollObserver/index.ts"](0, __webpack_exports__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('msft.ScrollObserver', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ScrollObserver);
} else {
	var msft = msft || {};
	msft.ScrollObserver = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ScrollObserver;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}